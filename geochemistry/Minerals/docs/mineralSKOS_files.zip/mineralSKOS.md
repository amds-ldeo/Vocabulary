---
comment: | 
  WARNING: This file is generated. Any edits will be lost!
format:
  html:
    ascii: true
    toc: true
    toc-depth: 4
    number-sections: true
    anchor-sections: false
    number-depth: 8
execute:
  echo: false
---

[]{#MineralSpecies}

# **Concept scheme:** Mineral Species

no modified date

subtitle: 
  TBD

Namespace: 
[`https://w3id.org/geochem/1.0/min/conceptScheme`](https://w3id.org/geochem/1.0/min/conceptScheme)

**History**

* 2024-03-20 S.M. Richard.  Draft generated, 
* based on 'Geoscience Ontology, Minerals', Brodaric, B., and Richard, S.M., 2021, The GeoScience Ontology Reference: Geological Survey of Canada Open File 8796, 34 p., https://doi.org/10.4095/328296.  Mineral names from RRUFF, with various properties from RRUFF, also Wikipedia scraped properties and links, joined by name with RRUFF plain string names.  Mindatid numbers are the group identifier tokens. The concept scheme includes the base scheme with mineral species, and includes (via skos:inScheme) a scheme for Strunz mineral classes and a scheme for mineral groups as defined in MinDat.

- [Garnet Supergroup](#1651)
    - [Cryolithionite](#cryolithionite)
    - [Katoite](#katoite)
    - [Priscillagrewite-(Y)](#priscillagrewite-y)
    - [Xuite](#xuite)
    - [Yafsoanite](#yafsoanite)

- [Apatite Supergroup](#274)
    - [Vanackerite](#vanackerite)

- [Perovskite Supergroup](#29176)

- [Sapphirine Supergroup](#29265)
    - [Beckettite](#beckettite)
    - [Khesinite](#khesinite)
    - [Surinamite](#surinamite)

- [Alunite Supergroup](#29267)

- [Copper Group](#32720)
    - [Copper](#copper)
    - [Gold](#gold)
    - [Maldonite](#maldonite)
    - [Silver](#silver)

- [Chalcoalumite Group](#39461)
    - [Chalcoalumite](#chalcoalumite)
    - [Kyrgyzstanite](#kyrgyzstanite)
    - [Mbobomkulite](#mbobomkulite)

- [Pharmacosiderite Supergroup](#40522)

- [Hydrotalcite Supergroup](#43290)
    - [Brugnatellite](#brugnatellite)
    - [Coalingite](#coalingite)
    - [Karchevskyite](#karchevskyite)
    - [Muskoxite](#muskoxite)

- [Dumortierite Supergroup](#43608)

- [Gypsum Supergroup](#46846)
    - [Brushite](#brushite)
    - [Churchite-(Y)](#churchite-y)
    - [Gypsum](#gypsum)
    - [Pharmacolite](#pharmacolite)

- [Betpakdalite Supergroup](#46876)

- [Palmierite Supergroup](#470787)

- [Gadolinite Supergroup](#50359)

- [Spinel Supergroup](#52865)

- [Arctite Supergroup](#53194)

- [Tsumcorite Group](#9265)
    - [Cabalzarite](#cabalzarite)
    - [Cobaltlotharmeyerite](#cobaltlotharmeyerite)
    - [Cobalttsumcorite](#cobalttsumcorite)
    - [Ferrilotharmeyerite](#ferrilotharmeyerite)
    - [Gartrellite](#gartrellite)
    - [Helmutwinklerite](#helmutwinklerite)
    - [Kaliochalcite](#kaliochalcite)
    - [Krettnichite](#krettnichite)
    - [Lotharmeyerite](#lotharmeyerite)
    - [Lukrahnite](#lukrahnite)
    - [Manganlotharmeyerite](#manganlotharmeyerite)
    - [Mawbyite](#mawbyite)
    - [Mounanaite](#mounanaite)
    - [Natrochalcite](#natrochalcite)
    - [Nickellotharmeyerite](#nickellotharmeyerite)
    - [Nickelschneebergite](#nickelschneebergite)
    - [Nickeltsumcorite](#nickeltsumcorite)
    - [Phosphogartrellite](#phosphogartrellite)
    - [Rappoldite](#rappoldite)
    - [Schneebergite](#schneebergite)
    - [Thometzekite](#thometzekite)
    - [Tsumcorite](#tsumcorite)
    - [Yancowinnaite](#yancowinnaite)
    - [Zincgartrellite](#zincgartrellite)

- [Strunz Class 01 - Elements](#s01)

- [Strunz Class 02 - Sulfide or Sulfosalt Minerals](#s02)
    - [Disulfodadsonite](#disulfodadsonite)
    - [Iron sulfide](#ironsulfide)
        - [Greigite](#greigite)
        - [Mackinawite](#mackinawite)
        - [Marcasite](#marcasite)
        - [Pyrite](#pyrite)
        - [Pyrrhotite](#pyrrhotite)
    - [Plumosite](#plumosite)

- [Strunz Class 03 - Halide Minerals](#s03)
    - [Fluornatrocoulsellite](#fluornatrocoulsellite)
    - [Panichiite](#panichiite)

- [Strunz Class 04 - Oxide, Hydroxide, Arsenite, etc. Minerals](#s04)
    - [Písekite-(Y)](#pisekite-y)

- [Strunz Class 05 - Carbonate or Nitrate Minerals](#s05)

- [Strunz Class 06 - Borate Minerals](#s06)
    - [Clinometaborite](#clinometaborite)

- [Strunz Class 07 - Sulfate, Chromate, Molybdate etc. Minerals](#s07)

- [Strunz Class 08 - Phosphate, Arsenate, or Vanadate Minerals](#s08)

- [Strunz Class 09 - Silicate Minerals](#s09)
    - [Aluminosilicate mineral](#aluminosilicate)
        - [Andalusite](#andalusite)
        - [Kyanite](#kyanite)
        - [Mullite](#mullite)
        - [Sillimanite](#sillimanite)
    - [Calc-silicate mineral](#calc-silicatemineral)
        - [Actinolite](#actinolite)
        - [Andradite](#andradite)
        - [Anorthite](#anorthite)
        - [Clinozoisite](#clinozoisite)
        - [Diopside](#diopside)
        - [Epidote](#epidote)
        - [Grossular](#grossular)
        - [Hedenbergite](#hedenbergite)
        - [Johannsenite](#johannsenite)
        - [Meionite](#meionite)
        - [Prehnite](#prehnite)
        - [Titanite](#titanite)
        - [Tremolite](#tremolite)
        - [Uvarovite](#uvarovite)
        - [Wollastonite](#wollastonite)
        - [Xonotlite](#xonotlite)
        - [Zoisite](#zoisite)
    - [Yegorovite](#yegorovite)

- [Strunz Class 10 - Organic compounds](#s10)
    - [Antipinite](#antipinite)

- [Mineral](#mineral_material)

**Concepts**

[]{#1651}

##  Garnet Supergroup


- Child of:
 [`Mineral_Material`](#Mineral_Material)

-

- **Source:**
https://w3id.org/geochem/1.0/min/smrMindatGroupQuery

- Concept URI token: 1651


[]{#cryolithionite}

###  Cryolithionite


- Child of:
 [`1651`](#1651)
 [`s03_CB`](#s03_CB)

- Concept URI token: cryolithionite


[]{#katoite}

###  Katoite


- Child of:
 [`1651`](#1651)
 [`s04_FF`](#s04_FF)

- Concept URI token: katoite


[]{#priscillagrewite-y}

###  Priscillagrewite-(Y)


- Child of:
 [`1651`](#1651)
 [`s04_CC`](#s04_CC)


- **Source:**
https://w3id.org/geochem/1.0/min/SMRadditions

- Concept URI token: priscillagrewite-y


[]{#xuite}

###  Xuite


- Child of:
 [`1651`](#1651)
 [`s04_CC`](#s04_CC)


- **Source:**
https://w3id.org/geochem/1.0/min/SMRadditions

- Concept URI token: xuite


[]{#yafsoanite}

###  Yafsoanite


- Child of:
 [`1651`](#1651)
 [`s04_CC`](#s04_CC)

- Concept URI token: yafsoanite



[]{#274}

##  Apatite Supergroup


- Child of:
 [`Mineral_Material`](#Mineral_Material)

-

- **Source:**
https://w3id.org/geochem/1.0/min/smrMindatGroupQuery

- Concept URI token: 274


[]{#vanackerite}

###  Vanackerite


- Child of:
 [`274`](#274)
 [`s08_BN`](#s08_BN)

- Concept URI token: vanackerite



[]{#29176}

##  Perovskite Supergroup


- Child of:
 [`Mineral_Material`](#Mineral_Material)

-

- **Source:**
https://w3id.org/geochem/1.0/min/smrMindatGroupQuery

- Concept URI token: 29176



[]{#29265}

##  Sapphirine Supergroup


- Child of:
 [`Mineral_Material`](#Mineral_Material)

-

- **Source:**
https://w3id.org/geochem/1.0/min/smrMindatGroupQuery

- Concept URI token: 29265


[]{#beckettite}

###  Beckettite


- Child of:
 [`29265`](#29265)
 [`s04_HC`](#s04_HC)


- **Source:**
https://w3id.org/geochem/1.0/min/SMRadditions

- Concept URI token: beckettite


[]{#khesinite}

###  Khesinite


- Child of:
 [`29265`](#29265)
 [`s09_DH`](#s09_DH)

- Concept URI token: khesinite


[]{#surinamite}

###  Surinamite


- Child of:
 [`29265`](#29265)
 [`s09_DH`](#s09_DH)

- Concept URI token: surinamite



[]{#29267}

##  Alunite Supergroup


- Child of:
 [`Mineral_Material`](#Mineral_Material)

-

- **Source:**
https://w3id.org/geochem/1.0/min/smrMindatGroupQuery

- Concept URI token: 29267



[]{#32720}

##  Copper Group


- Child of:
 [`Mineral_Material`](#Mineral_Material)

-

- **Source:**
https://w3id.org/geochem/1.0/min/smrMindatGroupQuery

- Concept URI token: 32720


[]{#copper}

###  Copper


- Child of:
 [`32720`](#32720)
 [`s01_AA`](#s01_AA)

- Concept URI token: copper


[]{#gold}

###  Gold


- Child of:
 [`32720`](#32720)
 [`s01_AA`](#s01_AA)

- Concept URI token: gold


[]{#maldonite}

###  Maldonite


- Child of:
 [`32720`](#32720)
 [`s02_AA`](#s02_AA)

- Concept URI token: maldonite


[]{#silver}

###  Silver


- Child of:
 [`32720`](#32720)
 [`s01_AA`](#s01_AA)

- Concept URI token: silver



[]{#39461}

##  Chalcoalumite Group


- Child of:
 [`Mineral_Material`](#Mineral_Material)

- Concept URI token: 39461


[]{#chalcoalumite}

###  Chalcoalumite


- Child of:
 [`39461`](#39461)
 [`s07_DD`](#s07_DD)

- Concept URI token: chalcoalumite


[]{#kyrgyzstanite}

###  Kyrgyzstanite


- Child of:
 [`39461`](#39461)
 [`s07_DD`](#s07_DD)

- Concept URI token: kyrgyzstanite


[]{#mbobomkulite}

###  Mbobomkulite


- Child of:
 [`39461`](#39461)
 [`s05_ND`](#s05_ND)

- Concept URI token: mbobomkulite



[]{#40522}

##  Pharmacosiderite Supergroup


- Child of:
 [`Mineral_Material`](#Mineral_Material)

-

- **Source:**
https://w3id.org/geochem/1.0/min/smrMindatGroupQuery

- Concept URI token: 40522



[]{#43290}

##  Hydrotalcite Supergroup


- Child of:
 [`Mineral_Material`](#Mineral_Material)

-

- **Source:**
https://w3id.org/geochem/1.0/min/smrMindatGroupQuery

- Concept URI token: 43290


[]{#brugnatellite}

###  Brugnatellite


- Child of:
 [`43290`](#43290)
 [`s05_DA`](#s05_DA)

- Concept URI token: brugnatellite


[]{#coalingite}

###  Coalingite


- Child of:
 [`43290`](#43290)
 [`s05_DA`](#s05_DA)

- Concept URI token: coalingite


[]{#karchevskyite}

###  Karchevskyite


- Child of:
 [`43290`](#43290)
 [`s05_DA`](#s05_DA)

- Concept URI token: karchevskyite


[]{#muskoxite}

###  Muskoxite


- Child of:
 [`43290`](#43290)
 [`s04_FL`](#s04_FL)

- Concept URI token: muskoxite



[]{#43608}

##  Dumortierite Supergroup


- Child of:
 [`Mineral_Material`](#Mineral_Material)

-

- **Source:**
https://w3id.org/geochem/1.0/min/smrMindatGroupQuery

- Concept URI token: 43608



[]{#46846}

##  Gypsum Supergroup


- Child of:
 [`Mineral_Material`](#Mineral_Material)

-

- **Source:**
https://w3id.org/geochem/1.0/min/smrMindatGroupQuery

- Concept URI token: 46846


[]{#brushite}

###  Brushite


- Child of:
 [`46846`](#46846)
 [`s08_CJ`](#s08_CJ)

- Concept URI token: brushite


[]{#churchite-y}

###  Churchite-(Y)


- Child of:
 [`46846`](#46846)
 [`s08_CJ`](#s08_CJ)

- Concept URI token: churchite-y


[]{#gypsum}

###  Gypsum


- Child of:
 [`46846`](#46846)
 [`s07_CD`](#s07_CD)

- Concept URI token: gypsum


[]{#pharmacolite}

###  Pharmacolite


- Child of:
 [`46846`](#46846)
 [`s08_CJ`](#s08_CJ)

- Concept URI token: pharmacolite



[]{#46876}

##  Betpakdalite Supergroup


- Child of:
 [`Mineral_Material`](#Mineral_Material)

-

- **Source:**
https://w3id.org/geochem/1.0/min/smrMindatGroupQuery

- Concept URI token: 46876



[]{#470787}

##  Palmierite Supergroup


- Child of:
 [`Mineral_Material`](#Mineral_Material)

-

- **Source:**
https://w3id.org/geochem/1.0/min/smrMindatGroupQuery

- Concept URI token: 470787



[]{#50359}

##  Gadolinite Supergroup


- Child of:
 [`Mineral_Material`](#Mineral_Material)

-

- **Source:**
https://w3id.org/geochem/1.0/min/smrMindatGroupQuery

- Concept URI token: 50359



[]{#52865}

##  Spinel Supergroup


- Child of:
 [`Mineral_Material`](#Mineral_Material)

-

- **Source:**
https://w3id.org/geochem/1.0/min/smrMindatGroupQuery

- Concept URI token: 52865



[]{#53194}

##  Arctite Supergroup


- Child of:
 [`Mineral_Material`](#Mineral_Material)

-

- **Source:**
https://w3id.org/geochem/1.0/min/smrMindatGroupQuery

- Concept URI token: 53194



[]{#9265}

##  Tsumcorite Group


- Child of:
 [`Mineral_Material`](#Mineral_Material)

-

- **Source:**
https://w3id.org/geochem/1.0/min/smrMindatGroupQuery

- Concept URI token: 9265


[]{#cabalzarite}

###  Cabalzarite


- Child of:
 [`9265`](#9265)
 [`s08_CG`](#s08_CG)

- Concept URI token: cabalzarite


[]{#cobaltlotharmeyerite}

###  Cobaltlotharmeyerite


- Child of:
 [`9265`](#9265)
 [`s08_CG`](#s08_CG)

- Concept URI token: cobaltlotharmeyerite


[]{#cobalttsumcorite}

###  Cobalttsumcorite


- Child of:
 [`9265`](#9265)
 [`s08_CG`](#s08_CG)

- Concept URI token: cobalttsumcorite


[]{#ferrilotharmeyerite}

###  Ferrilotharmeyerite


- Child of:
 [`9265`](#9265)
 [`s08_CG`](#s08_CG)

- Concept URI token: ferrilotharmeyerite


[]{#gartrellite}

###  Gartrellite


- Child of:
 [`9265`](#9265)
 [`s08_CG`](#s08_CG)

- Concept URI token: gartrellite


[]{#helmutwinklerite}

###  Helmutwinklerite


- Child of:
 [`9265`](#9265)
 [`s08_CG`](#s08_CG)

- Concept URI token: helmutwinklerite


[]{#kaliochalcite}

###  Kaliochalcite


- Child of:
 [`9265`](#9265)
 [`s07_DF`](#s07_DF)

- Concept URI token: kaliochalcite


[]{#krettnichite}

###  Krettnichite


- Child of:
 [`9265`](#9265)
 [`s08_CG`](#s08_CG)

- Concept URI token: krettnichite


[]{#lotharmeyerite}

###  Lotharmeyerite


- Child of:
 [`9265`](#9265)
 [`s08_CG`](#s08_CG)

- Concept URI token: lotharmeyerite


[]{#lukrahnite}

###  Lukrahnite


- Child of:
 [`9265`](#9265)
 [`s08_CG`](#s08_CG)

- Concept URI token: lukrahnite


[]{#manganlotharmeyerite}

###  Manganlotharmeyerite


- Child of:
 [`9265`](#9265)
 [`s08_CG`](#s08_CG)

- Concept URI token: manganlotharmeyerite


[]{#mawbyite}

###  Mawbyite


- Child of:
 [`9265`](#9265)
 [`s08_CG`](#s08_CG)

- Concept URI token: mawbyite


[]{#mounanaite}

###  Mounanaite


- Child of:
 [`9265`](#9265)
 [`s08_CG`](#s08_CG)

- Concept URI token: mounanaite


[]{#natrochalcite}

###  Natrochalcite


- Child of:
 [`9265`](#9265)
 [`s07_DF`](#s07_DF)

- Concept URI token: natrochalcite


[]{#nickellotharmeyerite}

###  Nickellotharmeyerite


- Child of:
 [`9265`](#9265)
 [`s08_CG`](#s08_CG)

- Concept URI token: nickellotharmeyerite


[]{#nickelschneebergite}

###  Nickelschneebergite


- Child of:
 [`9265`](#9265)
 [`s08_CG`](#s08_CG)

- Concept URI token: nickelschneebergite


[]{#nickeltsumcorite}

###  Nickeltsumcorite


- Child of:
 [`9265`](#9265)
 [`s08_CG`](#s08_CG)

- Concept URI token: nickeltsumcorite


[]{#phosphogartrellite}

###  Phosphogartrellite


- Child of:
 [`9265`](#9265)
 [`s08_CG`](#s08_CG)

- Concept URI token: phosphogartrellite


[]{#rappoldite}

###  Rappoldite


- Child of:
 [`9265`](#9265)
 [`s08_CG`](#s08_CG)

- Concept URI token: rappoldite


[]{#schneebergite}

###  Schneebergite


- Child of:
 [`9265`](#9265)
 [`s08_CG`](#s08_CG)

- Concept URI token: schneebergite


[]{#thometzekite}

###  Thometzekite


- Child of:
 [`9265`](#9265)
 [`s08_CG`](#s08_CG)

- Concept URI token: thometzekite


[]{#tsumcorite}

###  Tsumcorite


- Child of:
 [`9265`](#9265)
 [`s08_CG`](#s08_CG)

- Concept URI token: tsumcorite


[]{#yancowinnaite}

###  Yancowinnaite


- Child of:
 [`9265`](#9265)
 [`s08_CG`](#s08_CG)

- Concept URI token: yancowinnaite


[]{#zincgartrellite}

###  Zincgartrellite


- Child of:
 [`9265`](#9265)
 [`s08_CG`](#s08_CG)

- Concept URI token: zincgartrellite



[]{#s01}

##  Strunz Class 01 - Elements


- Child of:
 [`Mineral_Material`](#Mineral_Material)

- Concept URI token: s01



[]{#s02}

##  Strunz Class 02 - Sulfide or Sulfosalt Minerals


- Child of:
 [`Mineral_Material`](#Mineral_Material)

- Concept URI token: s02


[]{#disulfodadsonite}

###  Disulfodadsonite


- Child of:
 [`s02`](#s02)

- Concept URI token: disulfodadsonite


[]{#ironsulfide}

###  Iron sulfide


- Child of:
 [`s02`](#s02)

- A generic term, often used in petrology, to describe various
iron(II) sulfides. In terrestrial crustal rocks pyrite and marcasite
are the most commonly found iron sulfides.

- **Source:**
https://w3id.org/geochem/1.0/min/SMRadditions

- Concept URI token: ironsulfide


[]{#greigite}

####  Greigite


- Child of:
 [`ironsulfide`](#ironsulfide)
 [`52935`](#52935)
 [`s02_DA`](#s02_DA)

- Concept URI token: greigite


[]{#mackinawite}

####  Mackinawite


- Child of:
 [`ironsulfide`](#ironsulfide)
 [`s02_CC`](#s02_CC)

- Concept URI token: mackinawite


[]{#marcasite}

####  Marcasite


- Child of:
 [`ironsulfide`](#ironsulfide)
 [`29308`](#29308)

- Concept URI token: marcasite


[]{#pyrite}

####  Pyrite


- Child of:
 [`ironsulfide`](#ironsulfide)
 [`9258`](#9258)

- Concept URI token: pyrite


[]{#pyrrhotite}

####  Pyrrhotite


- Child of:
 [`ironsulfide`](#ironsulfide)
 [`39447`](#39447)

- Concept URI token: pyrrhotite


[]{#plumosite}

###  Plumosite


- Child of:
 [`s02`](#s02)

- A name that can refer to any 'feather ore', usually boulangerite,
but sometimes jamesonite, zinkenite or even a rarer sulphosalt (e.g.
owyheeite). It is a good idea to analyse any "plumosite". Jamesonite
and zinkenite can be more brittle than boulangerite.

- **Source:**
SMR add missing skos broader

- Concept URI token: plumosite



[]{#s03}

##  Strunz Class 03 - Halide Minerals


- Child of:
 [`Mineral_Material`](#Mineral_Material)

- Concept URI token: s03


[]{#fluornatrocoulsellite}

###  Fluornatrocoulsellite


- Child of:
 [`51904`](#51904)
 [`s03`](#s03)


- **Source:**
SMR add missing skos broader

- Concept URI token: fluornatrocoulsellite


[]{#panichiite}

###  Panichiite


- Child of:
 [`s03`](#s03)

- Concept URI token: panichiite



[]{#s04}

##  Strunz Class 04 - Oxide, Hydroxide, Arsenite, etc. Minerals


- Child of:
 [`Mineral_Material`](#Mineral_Material)

- Concept URI token: s04


[]{#pisekite-y}

###  Písekite-(Y)


- Child of:
 [`s04`](#s04)

- Concept URI token: pisekite-y



[]{#s05}

##  Strunz Class 05 - Carbonate or Nitrate Minerals


- Child of:
 [`Mineral_Material`](#Mineral_Material)

- Concept URI token: s05



[]{#s06}

##  Strunz Class 06 - Borate Minerals


- Child of:
 [`Mineral_Material`](#Mineral_Material)

- Concept URI token: s06


[]{#clinometaborite}

###  Clinometaborite


- Child of:
 [`s06`](#s06)
 [`s06_GD`](#s06_GD)

- Concept URI token: clinometaborite



[]{#s07}

##  Strunz Class 07 - Sulfate, Chromate, Molybdate etc. Minerals


- Child of:
 [`Mineral_Material`](#Mineral_Material)

- Concept URI token: s07



[]{#s08}

##  Strunz Class 08 - Phosphate, Arsenate, or Vanadate Minerals


- Child of:
 [`Mineral_Material`](#Mineral_Material)

- Concept URI token: s08



[]{#s09}

##  Strunz Class 09 - Silicate Minerals


- Child of:
 [`Mineral_Material`](#Mineral_Material)

- Concept URI token: s09


[]{#aluminosilicate}

###  Aluminosilicate mineral


- Child of:
 [`s09`](#s09)


- **Source:**
https://w3id.org/geochem/1.0/min/SMRadditions

- Concept URI token: aluminosilicate


[]{#andalusite}

####  Andalusite


- Child of:
 [`aluminosilicate`](#aluminosilicate)
 [`s09_AF`](#s09_AF)

- Concept URI token: andalusite


[]{#kyanite}

####  Kyanite


- Child of:
 [`aluminosilicate`](#aluminosilicate)
 [`s09_AF`](#s09_AF)

- Concept URI token: kyanite


[]{#mullite}

####  Mullite


- Child of:
 [`aluminosilicate`](#aluminosilicate)
 [`s09_AF`](#s09_AF)

- Concept URI token: mullite


[]{#sillimanite}

####  Sillimanite


- Child of:
 [`aluminosilicate`](#aluminosilicate)
 [`s09_AF`](#s09_AF)

- Concept URI token: sillimanite


[]{#calc-silicatemineral}

###  Calc-silicate mineral


- Child of:
 [`s09`](#s09)

- A petrological term for calcium-rich silicate minerals, especially:
Actinolite, Andradite, Anorthite, Clinozoisite, Diopside, Epidote,
Grossular, Hedenbergite, Johannsenite, Meionite, Prehnite, Pumpellyite
Subgroup, Titanite, Tremolite, Uvarovite, Vesuvianite group,
Wollastonite, Xonotlite, Zoisite.  {@en}

- **Source:**
https://w3id.org/geochem/1.0/min/SMRadditions

- Concept URI token: calc-silicatemineral


[]{#actinolite}

####  Actinolite


- Child of:
 [`calc-silicatemineral`](#calc-silicatemineral)
 [`52952`](#52952)

- Concept URI token: actinolite


[]{#andradite}

####  Andradite


- Child of:
 [`calc-silicatemineral`](#calc-silicatemineral)
 [`10272`](#10272)

- Concept URI token: andradite


[]{#anorthite}

####  Anorthite


- Child of:
 [`calc-silicatemineral`](#calc-silicatemineral)
 [`calcicplagioclase`](#calcicplagioclase)

- Concept URI token: anorthite


[]{#clinozoisite}

####  Clinozoisite


- Child of:
 [`calc-silicatemineral`](#calc-silicatemineral)
 [`46234`](#46234)

- Concept URI token: clinozoisite


[]{#diopside}

####  Diopside


- Child of:
 [`calc-silicatemineral`](#calc-silicatemineral)
 [`high-calciumpyroxene`](#high-calciumpyroxene)

- Concept URI token: diopside


[]{#epidote}

####  Epidote


- Child of:
 [`calc-silicatemineral`](#calc-silicatemineral)
 [`46234`](#46234)

- Concept URI token: epidote


[]{#grossular}

####  Grossular


- Child of:
 [`calc-silicatemineral`](#calc-silicatemineral)
 [`10272`](#10272)

- Concept URI token: grossular


[]{#hedenbergite}

####  Hedenbergite


- Child of:
 [`calc-silicatemineral`](#calc-silicatemineral)
 [`high-calciumpyroxene`](#high-calciumpyroxene)

- Concept URI token: hedenbergite


[]{#johannsenite}

####  Johannsenite


- Child of:
 [`calc-silicatemineral`](#calc-silicatemineral)
 [`7630`](#7630)

- Concept URI token: johannsenite


[]{#meionite}

####  Meionite


- Child of:
 [`calc-silicatemineral`](#calc-silicatemineral)
 [`8778`](#8778)

- Concept URI token: meionite


[]{#prehnite}

####  Prehnite


- Child of:
 [`calc-silicatemineral`](#calc-silicatemineral)
 [`s09_DP`](#s09_DP)

- Concept URI token: prehnite


[]{#titanite}

####  Titanite


- Child of:
 [`calc-silicatemineral`](#calc-silicatemineral)
 [`39493`](#39493)

- Concept URI token: titanite


[]{#tremolite}

####  Tremolite


- Child of:
 [`calc-silicatemineral`](#calc-silicatemineral)
 [`36873`](#36873)

- Concept URI token: tremolite


[]{#uvarovite}

####  Uvarovite


- Child of:
 [`calc-silicatemineral`](#calc-silicatemineral)
 [`10272`](#10272)

- Concept URI token: uvarovite


[]{#wollastonite}

####  Wollastonite


- Child of:
 [`calc-silicatemineral`](#calc-silicatemineral)
 [`39542`](#39542)
 [`s09_DG`](#s09_DG)

- Concept URI token: wollastonite


[]{#xonotlite}

####  Xonotlite


- Child of:
 [`calc-silicatemineral`](#calc-silicatemineral)
 [`s09_DG`](#s09_DG)

- Concept URI token: xonotlite


[]{#zoisite}

####  Zoisite


- Child of:
 [`calc-silicatemineral`](#calc-silicatemineral)
 [`s09_BG`](#s09_BG)

- Concept URI token: zoisite


[]{#yegorovite}

###  Yegorovite


- Child of:
 [`s09`](#s09)

- Concept URI token: yegorovite



[]{#s10}

##  Strunz Class 10 - Organic compounds


- Child of:
 [`Mineral_Material`](#Mineral_Material)

- Concept URI token: s10


[]{#antipinite}

###  Antipinite


- Child of:
 [`s10`](#s10)

- Concept URI token: antipinite



[]{#mineral_material}

##  Mineral


- An amount of mineral: denotes a single mineral (a unit cell) or an
aggregation of single minerals. All subtypes of Mineral currently
denote an aggregation, e.g. Quartz denotes an aggregation of quartz
unit cells.
- "A mineral is an element or chemical compound that is normally
crystalline and that has been formed as a result of geological
processes." Nickel, Ernest H. (1995), The definition of a mineral,
The Canadian Mineralogist. 33 (3): 689-90.
- Concept URI token: Mineral_Material



